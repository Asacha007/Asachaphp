<html>
    <head>
        <title>

        </title>
    </head>
    <body>
        <?php
            $Asacha=mysqli_connect("localhost", "root", "", "forms");

            $first_name=mysqli_real_escape_string($Asacha, $_POST['FirstName']);
            $second_name=mysqli_real_escape_string($Asacha, $_POST['SecondName']);
            $last_name=mysqli_real_escape_string($Asacha, $_POST['LastName']);
            $citizen=mysqli_real_escape_string($Asacha, $_POST['citizen']);
            $country=mysqli_real_escape_string($Asacha, $_POST['country']);
            $county=mysqli_real_escape_string($Asacha, $_POST['county']);
            $identity=mysqli_real_escape_string($Asacha, $_POST['identity']);
            $DOB=mysqli_real_escape_string($Asacha, $_POST['DOB']);
            $gender=mysqli_real_escape_string($Asacha, $_POST['Gender']);
            $education=mysqli_real_escape_string($Asacha, $_POST['education']);
            $disability=mysqli_real_escape_string($Asacha, $_POST['disability']);
            $religion=mysqli_real_escape_string($Asacha, $_POST['religion']);
            $postaladdress=mysqli_real_escape_string($Asacha, $_POST['postaladdress']);
            $postalcode=mysqli_real_escape_string($Asacha, $_POST['postalcode']);
            $town=mysqli_real_escape_string($Asacha, $_POST['town']);
            $telephone=mysqli_real_escape_string($Asacha, $_POST['telephone']);
            $mobile=mysqli_real_escape_string($Asacha, $_POST['mobile']);
            $email=mysqli_real_escape_string($Asacha, $_POST['email']);
            $course=mysqli_real_escape_string($Asacha, $_POST['course']);

            


            $table="INSERT INTO form_data(first_name, second_name, last_name, citizen, country, county, identity, DOB, gender, education, disability, religion, postaladdress, postalcode, town, telephone, mobile, email, course)
            VALUES('$first_name', '$second_name', '$last_name','$citizen','$country','$county','$identity','$DOB','$gender','$education','$disability','$religion','$postaladdress','$postalcode','$town','$telephone','$mobile','$email','$course')";

            if(mysqli_query($Asacha, $table))
            {
                echo "Data entry successful";
            }
            else
            {
                echo "Data entry not successful";
            }

            //Email
            $headers="From: Asacha Stewart";
            $subject="Successful Form Submission";
            $message="Dear $last_name $first_name, Your application has been successfully submitted for $course. Please await the outcome in two weeks time . Yours Registrar";

            mail($email, $subject, $message, $headers);
        ?>
    </body>
</html>